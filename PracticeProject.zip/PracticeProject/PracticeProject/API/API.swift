//
//  API.swift
//  API
//

import Foundation

protocol API {
    init()

    func fetchUsers(excludingUserWithID: String?, success: (UsersList) -> Void, failure: (FetchError) -> Void)
}

extension API {
    static func make() -> API {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/users") else {
                    print("Invalid url...")
                    return
                }
                URLSession.shared.dataTask(with: url) { data, response, error in
                    let books = try! JSONDecoder().decode([UsersList].self, from: data!)
                    print(books)
                    DispatchQueue.main.async {
                        completion(UsersList)
                    }
                }.resume()
                
            }
}

// TODO: Create a data type representing users-list (according to expected JSON response)
// (See the JSON response at: https://jsonplaceholder.typicode.com/users)
//
typealias UsersList = Any

// TODO (Bonus): Create a more specific error type.
// This can help identify the nature of a particular failure case.
// e.g. network timeout, badly formatted request or failing to decode/deserialize
// a response could cause failure in a network request.
//
typealias FetchError = Any
