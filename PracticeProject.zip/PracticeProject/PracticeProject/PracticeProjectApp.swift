//
//  PracticeProjectApp.swift
//  PracticeProject
//
//  
//


import SwiftUI

@main
struct PracticeProjectApp: App {
    var network = Network()

    var body: some Scene {
        WindowGroup {
            ContentView(network: network)
        }
    }
}
